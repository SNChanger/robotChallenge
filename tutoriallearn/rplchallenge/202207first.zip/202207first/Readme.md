# コンセプト
公式資料の内容でチャレンジしてみた系です

The Rust Programmingをローカルで動かして、一部改造したもののビルドになります。


# 参照資料URL
hello_world_start.exe
https://doc.rust-lang.org/stable/book/ch01-02-hello-world.html

guess_input_tool.exe
dice_tool.exe
自分の手でサイコロを振るのをやめる委員会
https://doc.rust-lang.org/stable/book/ch02-00-guessing-game-tutorial.html


